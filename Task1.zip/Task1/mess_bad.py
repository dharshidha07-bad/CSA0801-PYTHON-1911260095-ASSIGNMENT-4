# The ORIGINAL script from the question, unchanged except that the hard-coded path is
# replaced by the sample file so that it can be run here (the defects are still there).
f = open("mess_oct.txt")
data = f.read()
total = 0
report = ""
for line in data.split("\n"):
    try:
        parts = line.split(",")
        total = total + int(parts[2])
        report = report + parts[1] + " " + parts[2] + "\n"
    except:
        pass
print(report)
print("Total", total)
