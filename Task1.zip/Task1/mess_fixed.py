"""Task 1.2 - repaired mess-bill totaller."""
import sys
import time
import tracemalloc
import os
import tempfile
from decimal import Decimal, InvalidOperation


def total_mess_bills(path):
    """Return (total, report_lines, rejected). rejected = [(line_no, text, reason), ...]."""
    total = Decimal("0")
    report_lines = []
    rejected = []
    with open(path, encoding="utf-8") as f:               # closed automatically, even after an error
        for line_no, line in enumerate(f, start=1):        # one line in memory at a time
            line = line.strip()
            if not line:                                    # ignore blank lines (e.g. the last one)
                continue
            parts = [p.strip() for p in line.split(",")]
            if len(parts) != 3:
                rejected.append((line_no, line, f"expected 3 fields, found {len(parts)}"))
                continue
            reg_no, name, amount_text = parts
            try:
                amount = Decimal(amount_text)               # paise are kept exactly (no float error)
            except InvalidOperation:
                rejected.append((line_no, line, f"amount {amount_text!r} is not a number"))
                continue
            if not amount.is_finite() or amount < 0:
                rejected.append((line_no, line, "amount must be a finite number >= 0"))
                continue
            total += amount
            report_lines.append(f"{name} {amount}")
    return total, report_lines, rejected


def main(path):
    try:
        total, report_lines, rejected = total_mess_bills(path)
    except FileNotFoundError:
        print(f"File not found: {path}")
        return 1
    except PermissionError:
        print(f"No permission to read: {path}")
        return 1
    print("\n".join(report_lines))
    print("Total", total)
    print(f"Rejected lines: {len(rejected)}")
    for line_no, text, reason in rejected:
        print(f"  line {line_no}: {text!r} -> {reason}")
    return 0


# ---- the three ways of reading, used only for the memory/time experiment (Alternative concept)
def total_read_all(path):
    with open(path, encoding="utf-8") as f:
        data = f.read()
    total = Decimal("0")
    for line in data.split("\n"):
        if line.strip():
            try:
                total += Decimal(line.split(",")[2])
            except (IndexError, InvalidOperation):
                pass
    return total


def total_readlines(path):
    with open(path, encoding="utf-8") as f:
        lines = f.readlines()
    total = Decimal("0")
    for line in lines:
        if line.strip():
            try:
                total += Decimal(line.split(",")[2])
            except (IndexError, InvalidOperation):
                pass
    return total


def total_iterate(path):
    total = Decimal("0")
    with open(path, encoding="utf-8") as f:
        for line in f:
            if line.strip():
                try:
                    total += Decimal(line.split(",")[2])
                except (IndexError, InvalidOperation):
                    pass
    return total


def make_big_file(path, n=50_000):
    with open(path, "w", encoding="utf-8") as f:
        for i in range(n):
            if i % 100 == 99:
                f.write(f"1923{i:05d},Student {i}\n")              # damaged: only 2 fields
            else:
                f.write(f"1923{i:05d},Student {i},{1000 + (i % 700)}.{i % 100:02d}\n")


if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    sample = os.path.join(here, "mess_oct.txt")
    print("=== Original script on the sample file ===")
    os.chdir(here)
    os.system(f'"{sys.executable}" mess_bad.py')
    print("\n=== Repaired script on the same file ===")
    main(sample)
    print("\n=== Missing file is reported, not a crash ===")
    main(os.path.join(here, "no_such_file.txt"))

    print("\n=== 50,000-line file: time and peak memory ===")
    tmp = os.path.join(tempfile.gettempdir(), "mess_big.txt")
    make_big_file(tmp)
    size_mb = os.path.getsize(tmp) / 1e6
    print(f"File size: {size_mb:.2f} MB, 50,000 lines (1% damaged)")
    results = {}
    for name, fn in (("f.read()", total_read_all), ("f.readlines()", total_readlines), ("line by line", total_iterate)):
        best = float("inf")
        for _ in range(3):
            t0 = time.perf_counter()
            r = fn(tmp)
            best = min(best, time.perf_counter() - t0)
        tracemalloc.start()
        fn(tmp)
        peak = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        results[name] = (best, peak, r)
        print(f"  {name:<14} time={best:.4f}s  peak memory={peak / 1e6:.2f} MB  total={r}")
    assert len({v[2] for v in results.values()}) == 1
    t0 = time.perf_counter()
    total, lines, rej = total_mess_bills(tmp)
    print(f"  repaired function (full checks, list of rejects): {time.perf_counter() - t0:.4f}s, "
          f"{len(lines)} accepted, {len(rej)} rejected, first reject: {rej[0]}")
    os.remove(tmp)
