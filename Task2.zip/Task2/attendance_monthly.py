"""Task 2 - Monthly biometric attendance processing.

Input : a folder of daily files, each line  register_number,date,status   (status = P or A)
Output: attendance_summary.csv, below_75.txt, damaged_lines.log
"""
import csv
import os
import shutil
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path

THRESHOLD = 75.0


def check_line(line):
    """Return (reg, date, status) or raise ValueError(reason) for a damaged line."""
    text = line.strip()
    if not text:
        raise ValueError("empty line")
    parts = [p.strip() for p in text.split(",")]
    if len(parts) != 3:
        raise ValueError(f"expected 3 fields, found {len(parts)}")
    reg, date, status = parts
    if not (reg.isdigit() and len(reg) == 9):
        raise ValueError(f"invalid register number {reg!r}")
    try:
        datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        raise ValueError(f"invalid date {date!r}") from None
    if status not in ("P", "A"):
        raise ValueError(f"invalid status {status!r}")
    return reg, date, status


def read_month(folder):
    """One pass over every daily file. Returns (counts, damaged)."""
    counts = {}                 # reg -> [present, absent]
    seen = set()                # (reg, date) already counted -> detects duplicates
    damaged = []                # (file name, line number, line text, reason)
    for path in sorted(Path(folder).glob("attendance_*.txt")):
        try:
            with open(path, encoding="utf-8") as f:
                for line_no, line in enumerate(f, start=1):
                    try:
                        reg, date, status = check_line(line)
                        if (reg, date) in seen:
                            raise ValueError("duplicate record for this student and date")
                    except ValueError as err:
                        damaged.append((path.name, line_no, line.rstrip("\n"), str(err)))
                        continue
                    seen.add((reg, date))
                    entry = counts.setdefault(reg, [0, 0])
                    entry[0 if status == "P" else 1] += 1
        except (OSError, UnicodeDecodeError) as err:        # unreadable file: log it, carry on
            damaged.append((path.name, 0, "", f"file could not be read: {err}"))
    return counts, damaged


def write_reports(counts, damaged, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    below = []
    with open(os.path.join(out_dir, "attendance_summary.csv"), "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["register_number", "present", "absent", "percentage"])
        for reg in sorted(counts):
            p, a = counts[reg]
            pct = 100.0 * p / (p + a)
            w.writerow([reg, p, a, f"{pct:.1f}"])
            if pct < THRESHOLD:
                below.append((reg, pct))
    with open(os.path.join(out_dir, "below_75.txt"), "w", encoding="utf-8") as f:
        for reg, pct in below:
            f.write(f"{reg} {pct:.1f}%\n")
    with open(os.path.join(out_dir, "damaged_lines.log"), "w", encoding="utf-8") as f:
        for name, no, text, reason in damaged:
            f.write(f"{name}:{no}: {reason} | {text!r}\n")
    return below


def percentages_reread(students, folder):
    """Alternative concept: for each student re-read every file (O(s*f*l))."""
    result = {}
    for reg in students:
        p = a = 0
        seen = set()
        for path in sorted(Path(folder).glob("attendance_*.txt")):
            with open(path, encoding="utf-8") as f:
                for line in f:
                    try:
                        r, date, status = check_line(line)       # same validation as the one-pass method
                    except ValueError:
                        continue
                    if r == reg and (r, date) not in seen:
                        seen.add((r, date))
                        if status == "P":
                            p += 1
                        else:
                            a += 1
        result[reg] = [p, a]
    return result


if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    data, out = os.path.join(here, "sample_data"), os.path.join(here, "out")
    counts, damaged = read_month(data)
    below = write_reports(counts, damaged, out)
    print("== attendance_summary.csv ==")
    print(open(os.path.join(out, "attendance_summary.csv")).read())
    print("== below_75.txt ==")
    print(open(os.path.join(out, "below_75.txt")).read())
    print("== damaged_lines.log ==")
    print(open(os.path.join(out, "damaged_lines.log")).read())

    print("== Trace file (Task 2.4) ==")
    tmp = tempfile.mkdtemp()
    with open(os.path.join(tmp, "attendance_2026-10-08.txt"), "w", encoding="utf-8") as f:
        f.write("192311001,2026-10-08,P\n192311002,2026-10-08,A\n192311003,2026-10-08\n192311001,2026-10-09,P\n")
    c, d = read_month(tmp)
    print("counts :", c)
    print("damaged:", d)
    shutil.rmtree(tmp)

    print("\n== Alternative: re-read all files for every student vs one pass ==")
    ok = counts == percentages_reread(sorted(counts), data)
    print("same counts from both methods:", ok)
    rows = []
    for s in (10, 50, 100, 200):
        folder = tempfile.mkdtemp()
        students = [f"1923{i:05d}" for i in range(s)]
        for day in range(30):                                   # f = 30 files, l = s lines each
            with open(os.path.join(folder, f"attendance_2026-10-{day + 1:02d}.txt"), "w", encoding="utf-8") as f:
                f.write("\n".join(f"{r},2026-10-{day + 1:02d},{'P' if (day + int(r)) % 4 else 'A'}" for r in students) + "\n")
        t0 = time.perf_counter(); read_month(folder); t_one = time.perf_counter() - t0
        t0 = time.perf_counter(); percentages_reread(students, folder); t_re = time.perf_counter() - t0
        rows.append((s, 30, s, t_one, t_re))
        print(f"  s={s:>4} students, f=30 files, l={s:>4} lines/file: one pass={t_one:.4f}s  re-read per student={t_re:.4f}s  ratio={t_re / t_one:.0f}x")
        shutil.rmtree(folder)
