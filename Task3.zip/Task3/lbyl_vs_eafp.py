"""Task 3 alternative: raise/catch exceptions (EAFP) versus checking with if (LBYL)."""
import random
import time


class InvalidRecord(Exception):
    pass


def parse_eafp(line):
    parts = line.split(",")
    if len(parts) != 3:
        raise InvalidRecord("fields")
    if parts[2] not in ("P", "A"):
        raise InvalidRecord("status")
    return parts


def process_eafp(lines):
    good = bad = 0
    for line in lines:
        try:
            parse_eafp(line)
        except InvalidRecord:
            bad += 1
        else:
            good += 1
    return good, bad


def check_lbyl(line):
    parts = line.split(",")
    if len(parts) != 3 or parts[2] not in ("P", "A"):
        return None
    return parts


def process_lbyl(lines):
    good = bad = 0
    for line in lines:
        if check_lbyl(line) is None:
            bad += 1
        else:
            good += 1
    return good, bad


def make_lines(n, bad_fraction, seed=2):
    rnd = random.Random(seed)
    return ["192311001,2026-10-08" if rnd.random() < bad_fraction else "192311001,2026-10-08,P" for _ in range(n)]


def best(fn, arg, repeat=5):
    t = float("inf")
    for _ in range(repeat):
        t0 = time.perf_counter()
        fn(arg)
        t = min(t, time.perf_counter() - t0)
    return t


if __name__ == "__main__":
    n = 200_000
    print(f"{n:,} lines; time per line (best of 5)")
    print(f"{'bad lines':>10} {'EAFP (try/except)':>20} {'LBYL (if)':>14} {'EAFP / LBYL':>12}")
    for frac in (0.0, 0.001, 0.01, 0.1, 0.5, 1.0):
        lines = make_lines(n, frac)
        assert process_eafp(lines) == process_lbyl(lines)
        a, b = best(process_eafp, lines) / n, best(process_lbyl, lines) / n
        print(f"{frac * 100:>9.1f}% {a * 1e9:>17.0f} ns {b * 1e9:>11.0f} ns {a / b:>11.2f}x")
