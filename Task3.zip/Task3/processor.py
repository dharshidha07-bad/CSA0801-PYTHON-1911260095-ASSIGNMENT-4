"""Task 3 - attendance processor with a custom exception and a complete try statement."""
import os
import tempfile
from datetime import datetime


class InvalidRecord(Exception):
    """A line of an attendance file is not in the expected format (raised in parse_line)."""


def parse_line(line):
    parts = line.strip().split(",")
    if len(parts) != 3:
        raise InvalidRecord(f"expected 3 fields, found {len(parts)}")
    reg, date, status = (p.strip() for p in parts)
    try:
        datetime.strptime(date, "%Y-%m-%d")
    except ValueError as err:
        raise InvalidRecord(f"invalid date {date!r}") from err         # keeps the original cause
    if status not in ("P", "A"):
        raise InvalidRecord(f"invalid status {status!r}")
    return reg, date, status


def process_file(path):
    """Return (present, absent, errors). Handles each kind of failure separately."""
    present = absent = 0
    errors = []
    try:
        f = open(path, encoding="utf-8")
    except FileNotFoundError as err:
        raise RuntimeError(f"attendance file missing: {path}") from err
    except PermissionError as err:
        raise RuntimeError(f"no permission to read: {path}") from err
    try:
        for line_no, line in enumerate(f, start=1):
            try:
                _, _, status = parse_line(line)
            except InvalidRecord as err:              # handled HERE: one bad line must not stop the file
                errors.append((line_no, str(err), repr(err.__cause__) if err.__cause__ else None))
            else:                                     # runs only when parse_line succeeded
                if status == "P":
                    present += 1
                else:
                    absent += 1
    except UnicodeDecodeError as err:                 # wrong encoding is detected while reading
        raise RuntimeError(f"file {path} is not valid UTF-8") from err
    finally:                                          # runs always: the file is closed in every case
        f.close()
    return present, absent, errors


def percentage(present, absent):
    total = present + absent
    if total == 0:                                    # empty file: avoid ZeroDivisionError
        return None
    return 100.0 * present / total


def summarise_buggy(path):
    """Task 3.4: specific excepts replaced by 'except Exception: pass', plus a typing error."""
    present = absent = 0
    with open(path, encoding="utf-8") as f:
        for line in f:
            try:
                _, _, status = parse_line(line)
                if status == "P":
                    presnt += 1                       # typing error: should be 'present'
                else:
                    absent += 1
            except Exception:
                pass
    return present, absent


if __name__ == "__main__":
    tmp = tempfile.mkdtemp()
    good = os.path.join(tmp, "day.csv")
    with open(good, "w", encoding="utf-8") as f:
        f.write("192311001,2026-10-08,P\n192311002,2026-10-08,A\n192311003,2026-10-08\n"
                "192311004,2026-13-08,P\n192311005,2026-10-08,L\n192311006,2026-10-08,P\n")

    print("=== Task 3.1 - every failure, triggered on purpose ===")
    def show(label, fn):
        try:
            fn()
            print(f"  {label:<26} -> no exception")
        except Exception as e:
            print(f"  {label:<26} -> {type(e).__name__}: {e}")
    show("missing folder", lambda: os.listdir(os.path.join(tmp, "nofolder")))
    show("missing file", lambda: open(os.path.join(tmp, "nofile.csv"), encoding="utf-8"))
    show("opening a folder as file", lambda: open(tmp, encoding="utf-8"))      # PermissionError on Windows
    bad = os.path.join(tmp, "latin.csv")
    with open(bad, "wb") as f:
        f.write(b"192311001,2026-10-08,P\n\xff\xfe\xfa,2026-10-08,A\n")
    show("wrong encoding", lambda: open(bad, encoding="utf-8").read())
    def unpack_three():
        reg, date, status = "192311001,2026-10-08".split(",")
    show("damaged line (unpack)", unpack_three)
    show("damaged line (index)", lambda: "192311001,2026-10-08".split(",")[2])
    show("damaged line (number)", lambda: int("P"))
    empty = os.path.join(tmp, "empty.csv")
    open(empty, "w").close()
    show("empty file (no lines)", lambda: open(empty, encoding="utf-8").read())
    show("percentage of empty file", lambda: 100 * 0 / (0 + 0))

    print("\n=== Task 3.2/3.3 - processor with InvalidRecord and try/except/else/finally ===")
    p, a, errs = process_file(good)
    print("present:", p, "absent:", a)
    for e in errs:
        print("  invalid line", e)
    print("percentage:", percentage(p, a), "| empty file percentage:", percentage(0, 0))
    for label, path in (("missing file", os.path.join(tmp, "nofile.csv")), ("wrong encoding", bad)):
        try:
            process_file(path)
        except RuntimeError as e:
            print(f"  {label}: RuntimeError: {e}   <- caused by {e.__cause__!r}")

    print("\n=== Task 3.4 - misuse experiment ===")
    print("correct result for the file (present, absent) =", process_file(good)[:2])
    print("with 'except Exception: pass' and the typing error 'presnt' =", summarise_buggy(good))
    clean = os.path.join(tmp, "clean.csv")
    with open(clean, "w", encoding="utf-8") as f:
        f.write("192311001,2026-10-08,P\n192311002,2026-10-08,A\n")
    print("clean two-line file, blanket except + typo ->", summarise_buggy(clean), "(correct answer is (1, 1))")
    try:
        with open(clean, encoding="utf-8") as f:
            for line in f:
                if parse_line(line)[2] == "P":
                    presnt += 1                           # same typing error, no blanket except
    except NameError as e:
        print("same typo without the blanket except -> Python reports", type(e).__name__ + ":", e)
