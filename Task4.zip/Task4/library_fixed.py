"""Task 4.3 - repaired library return-log program."""
import os
from datetime import datetime


def save_returns(books, log_path="returns.log"):
    with open(log_path, "a", encoding="utf-8") as log:      # "a": earlier days are kept; with: always closed
        for b in books:
            log.write(b + "\n")                              # newline after every book


def log_error(day_file, err, error_log="errors.log"):
    with open(error_log, "a", encoding="utf-8") as elog:
        elog.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {day_file}: {type(err).__name__}: {err}\n")


def process(day_file, log_path="returns.log", error_log="errors.log"):
    try:
        with open(day_file, encoding="utf-8") as f:
            books = [line.strip() for line in f if line.strip()]
        save_returns(books, log_path)
    except FileNotFoundError as err:
        log_error(day_file, err, error_log)
        return False
    except (OSError, UnicodeDecodeError, TypeError) as err:  # permission, bad encoding, bad data
        log_error(day_file, err, error_log)
        return False
    return True


def save_returns_finally(books, log_path="returns.log"):
    """Alternative concept: manual open/close with try/finally."""
    log = open(log_path, "a", encoding="utf-8")
    try:
        for b in books:
            log.write(b + "\n")
    finally:
        log.close()
