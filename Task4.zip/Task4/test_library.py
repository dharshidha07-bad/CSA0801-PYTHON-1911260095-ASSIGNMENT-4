"""Task 4.2 / 4.3 - evidence for each defect, then the repaired program on the same tests."""
import builtins
import gc
import os
import tempfile
import time
import warnings

import library_bad
import library_fixed

tmp = tempfile.mkdtemp()
os.chdir(tmp)
days = {"mon.txt": ["Python Basics", "Data Structures"], "tue.txt": ["Algorithms"], "wed.txt": ["Networks", "Databases"]}
for name, books in days.items():
    with open(name, "w", encoding="utf-8") as f:
        f.write("\n".join(books) + "\n")


class OpenTracker:
    """Records every file object opened through builtins.open so we can see which stay open."""
    def __enter__(self):
        self.handles = []
        self._real = builtins.open

        def tracking_open(*a, **k):
            h = self._real(*a, **k)
            self.handles.append(h)
            return h
        builtins.open = tracking_open
        return self

    def __exit__(self, *exc):
        builtins.open = self._real
        return False

    def still_open(self):
        return sum(1 for h in self.handles if not h.closed)


print("=== ORIGINAL program: three days, then the log ===")
for name in days:
    library_bad.process(name)
print(repr(open("returns.log").read()))
print("-> only Wednesday survives (mode 'w' truncates the file on every call); books are glued together")
print("   ('NetworksDatabases') because no newline is written; the trailing '' from split() adds nothing.")

print("\n=== ORIGINAL: write() fails half-way (one item is not a string) ===")
with OpenTracker() as t:
    try:
        library_bad.save_returns(["Algebra", 404, "Physics"])
    except TypeError as e:
        print("TypeError:", e)
        print("inside the except block, files still open:", t.still_open(), "-> close() was never reached")
print("process() catches only FileNotFoundError, so this TypeError would crash the program with no message saved.")
print("CPython closes the abandoned file only when the traceback is released (garbage collection); that is an")
print("implementation detail: the buffered text may be flushed late, and the file stays locked on Windows meanwhile.")

print("\n=== ORIGINAL: process() never closes the day file (open(day_file).read()) ===")
with warnings.catch_warnings(record=True) as w:
    warnings.simplefilter("always")
    library_bad.process("mon.txt")
    gc.collect()
print("ResourceWarning messages raised by Python:", [str(x.message)[:40] + "..." for x in w if issubclass(x.category, ResourceWarning)])

os.remove("returns.log")
print("\n=== REPAIRED program, same three days + a missing day + a bad-encoding day ===")
with open("thu.txt", "wb") as f:
    f.write(b"Chemistry\n\xff\xfe\n")
for name in list(days) + ["fri_missing.txt", "thu.txt"]:
    ok = library_fixed.process(name)
    print(f"  {name:<16} processed: {ok}")
print("returns.log:")
print(open("returns.log").read())
print("errors.log:")
print(open("errors.log").read())

print("=== REPAIRED: failing write leaves no file open ===")
with OpenTracker() as t:
    try:
        library_fixed.save_returns(["Algebra", 404, "Physics"])
    except TypeError as e:
        print("TypeError:", e)
        print("with-statement version, inside the except block, files still open:", t.still_open())
with OpenTracker() as t:
    try:
        library_fixed.save_returns_finally(["Algebra", 404, "Physics"])
    except TypeError:
        print("try/finally version, inside the except block, files still open:", t.still_open())

print("\n=== Alternative concept: time of with versus try/finally (20,000 calls, 5 lines each) ===")
books = ["a", "b", "c", "d", "e"]
for label, fn in (("with statement", library_fixed.save_returns), ("try/finally", library_fixed.save_returns_finally)):
    best = float("inf")
    for _ in range(3):
        t0 = time.perf_counter()
        for _ in range(20_000):
            fn(books, "speed.log")
        best = min(best, time.perf_counter() - t0)
    print(f"  {label:<15} {best:.3f} s")
