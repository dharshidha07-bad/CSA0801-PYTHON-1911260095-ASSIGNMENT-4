"""Task 5 - the same attendance utility organised four ways, before and after a new requirement.

Creates organisations_before/ and organisations_after/ (identical logic in every organisation),
runs every organisation on sample_data/, checks that the outputs are the same, and counts the
files and lines that had to change for the new report (students absent 3 days in a row).
"""
import difflib
import filecmp
import os
import shutil
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))

IMPORTS_READER = "from datetime import datetime\nfrom pathlib import Path\n"
IMPORTS_REPORT = "import csv\n"

READER = '''def check_line(line):
    """Return (reg, date, status) or raise ValueError(reason) for a damaged line."""
    text = line.strip()
    if not text:
        raise ValueError("empty line")
    parts = [p.strip() for p in text.split(",")]
    if len(parts) != 3:
        raise ValueError(f"expected 3 fields, found {len(parts)}")
    reg, date, status = parts
    if not (reg.isdigit() and len(reg) == 9):
        raise ValueError(f"invalid register number {reg!r}")
    try:
        datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        raise ValueError(f"invalid date {date!r}") from None
    if status not in ("P", "A"):
        raise ValueError(f"invalid status {status!r}")
    return reg, date, status


def read_month(folder):
    """One pass over the daily files. Returns (records, damaged)."""
    records, seen, damaged = [], set(), []
    for path in sorted(Path(folder).glob("attendance_*.txt")):
        try:
            with open(path, encoding="utf-8") as f:
                for line_no, line in enumerate(f, start=1):
                    try:
                        reg, date, status = check_line(line)
                        if (reg, date) in seen:
                            raise ValueError("duplicate record for this student and date")
                    except ValueError as err:
                        damaged.append((path.name, line_no, line.rstrip("\\n"), str(err)))
                        continue
                    seen.add((reg, date))
                    records.append((reg, date, status))
        except (OSError, UnicodeDecodeError) as err:
            damaged.append((path.name, 0, "", f"file could not be read: {err}"))
    return records, damaged
'''

STATS = '''def count_attendance(records):
    counts = {}
    for reg, date, status in records:
        entry = counts.setdefault(reg, [0, 0])
        entry[0 if status == "P" else 1] += 1
    return counts


def percentages(counts):
    return {reg: 100.0 * p / (p + a) for reg, (p, a) in counts.items()}


def below_threshold(pcts, limit=75.0):
    return sorted((reg, pct) for reg, pct in pcts.items() if pct < limit)
'''

STATS_ADD = '''

def absent_streaks(records, run_length=3):
    """Students absent on run_length or more consecutive recorded days: {reg: (first, last, days)}."""
    by_student = {}
    for reg, date, status in records:
        by_student.setdefault(reg, []).append((date, status))
    streaks = {}
    for reg, days in by_student.items():
        days.sort()
        run, best = [], []
        for date, status in days:
            if status == "A":
                run.append(date)
                if len(run) > len(best):
                    best = list(run)
            else:
                run = []
        if len(best) >= run_length:
            streaks[reg] = (best[0], best[-1], len(best))
    return streaks
'''

REPORT = '''def write_summary(path, counts, pcts):
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["register_number", "present", "absent", "percentage"])
        for reg in sorted(counts):
            w.writerow([reg, counts[reg][0], counts[reg][1], f"{pcts[reg]:.1f}"])


def write_below(path, below):
    with open(path, "w", encoding="utf-8") as f:
        for reg, pct in below:
            f.write(f"{reg} {pct:.1f}%\\n")


def write_damaged(path, damaged):
    with open(path, "w", encoding="utf-8") as f:
        for name, no, text, reason in damaged:
            f.write(f"{name}:{no}: {reason} | {text!r}\\n")
'''

REPORT_ADD = '''

def write_streaks(path, streaks):
    with open(path, "w", encoding="utf-8") as f:
        for reg in sorted(streaks):
            first, last, n = streaks[reg]
            f.write(f"{reg} absent {n} days in a row: {first} to {last}\\n")
'''


def run_body(r, s, p, after):
    """The orchestration function; r, s, p are the prefixes used to call the reader, stats and report functions."""
    body = f'''def run(data_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    records, damaged = {r}read_month(data_dir)
    counts = {s}count_attendance(records)
    pcts = {s}percentages(counts)
    below = {s}below_threshold(pcts)
    {p}write_summary(os.path.join(out_dir, "attendance_summary.csv"), counts, pcts)
    {p}write_below(os.path.join(out_dir, "below_75.txt"), below)
    {p}write_damaged(os.path.join(out_dir, "damaged_lines.log"), damaged)
'''
    if after:
        body += f'''    streaks = {s}absent_streaks(records)
    {p}write_streaks(os.path.join(out_dir, "absent_3_days.txt"), streaks)
'''
    body += '''    print(f"{len(counts)} students, {len(below)} below 75%, {len(damaged)} damaged lines")
'''
    return body


MAIN_GUARD = '''

if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("usage: python main.py <data folder> <output folder>")
    run(sys.argv[1], sys.argv[2])
'''


def organisations(after):
    orgs = {}
    # (a) one script ---------------------------------------------------------------
    orgs["a_one_script"] = {"attendance.py": (
        '"""Attendance processor - everything in one script."""\nimport csv\nimport os\nimport sys\n'
        + IMPORTS_READER + "\n\n" + READER + "\n\n" + STATS + (STATS_ADD if after else "") + "\n\n" + REPORT
        + (REPORT_ADD if after else "") + "\n\n" + run_body("", "", "", after) + MAIN_GUARD)}
    # (b) one module + main -----------------------------------------------------------
    orgs["b_one_module"] = {
        "attendance_lib.py": '"""Library module: reading, statistics and reports."""\nimport csv\n' + IMPORTS_READER
        + "\n\n" + READER + "\n\n" + STATS + (STATS_ADD if after else "") + "\n\n" + REPORT + (REPORT_ADD if after else ""),
        "main.py": '"""Main script."""\nimport os\nimport sys\n\nimport attendance_lib as al\n\n\n'
        + run_body("al.", "al.", "al.", after) + MAIN_GUARD}
    # (c) three modules in one folder ------------------------------------------------------
    orgs["c_three_modules"] = {
        "reader.py": '"""Reading the daily files."""\n' + IMPORTS_READER + "\n\n" + READER,
        "stats.py": '"""Statistics."""\n\n\n' + STATS + (STATS_ADD if after else ""),
        "report.py": '"""Writing the reports."""\n' + IMPORTS_REPORT + "\n\n" + REPORT + (REPORT_ADD if after else ""),
        "main.py": '"""Main script."""\nimport os\nimport sys\n\nimport reader\nimport stats\nimport report\n\n\n'
        + run_body("reader.", "stats.", "report.", after) + MAIN_GUARD}
    # (d) package -------------------------------------------------------------------------
    orgs["d_package"] = {
        "attendance/__init__.py": '"""attendance package: reader, stats and report sub-modules."""\n__all__ = ["reader", "stats", "report"]\n',
        "attendance/reader.py": '"""Reading the daily files."""\n' + IMPORTS_READER + "\n\n" + READER,
        "attendance/stats.py": '"""Statistics."""\n\n\n' + STATS + (STATS_ADD if after else ""),
        "attendance/report.py": '"""Writing the reports."""\n' + IMPORTS_REPORT + "\n\n" + REPORT + (REPORT_ADD if after else ""),
        "main.py": '"""Main script."""\nimport os\nimport sys\n\nfrom attendance import reader, stats, report\n\n\n'
        + run_body("reader.", "stats.", "report.", after) + MAIN_GUARD}
    return orgs


def write_tree(root, after):
    shutil.rmtree(root, ignore_errors=True)
    for org, files in organisations(after).items():
        for rel, text in files.items():
            path = os.path.join(root, org, rel)
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8", newline="\n") as f:
                f.write(text)


def entry_point(org):
    return "attendance.py" if org == "a_one_script" else "main.py"


def run_org(root, org, out):
    folder = os.path.join(root, org)
    shutil.rmtree(out, ignore_errors=True)
    res = subprocess.run([sys.executable, entry_point(org), os.path.join(HERE, "sample_data"), out],
                         cwd=folder, capture_output=True, text=True)
    if res.returncode != 0:
        sys.exit(res.stderr)
    return res.stdout.strip()


def count_lines(root, org):
    total, files = 0, 0
    for base, _, names in os.walk(os.path.join(root, org)):
        for n in names:
            if n.endswith(".py"):
                files += 1
                total += len(open(os.path.join(base, n), encoding="utf-8").read().splitlines())
    return files, total


if __name__ == "__main__":
    before, after = os.path.join(HERE, "organisations_before"), os.path.join(HERE, "organisations_after")
    write_tree(before, False)
    write_tree(after, True)
    outs = {}
    print("=== Task 5.1 - four organisations, same data, same results ===")
    for org in organisations(False):
        for label, root in (("before", before), ("after", after)):
            outs[(org, label)] = os.path.join(HERE, "out", label, org)
            msg = run_org(root, org, outs[(org, label)])
            if label == "before":
                print(f"{org:<17} {msg}")
    ref_b = outs[("a_one_script", "before")]
    ref_a = outs[("a_one_script", "after")]
    for org in organisations(False):
        for name in ("attendance_summary.csv", "below_75.txt", "damaged_lines.log"):
            assert filecmp.cmp(os.path.join(ref_b, name), os.path.join(outs[(org, "before")], name), shallow=False), (org, name)
            assert filecmp.cmp(os.path.join(ref_a, name), os.path.join(outs[(org, "after")], name), shallow=False), (org, name)
        assert filecmp.cmp(os.path.join(ref_a, "absent_3_days.txt"), os.path.join(outs[(org, "after")], "absent_3_days.txt"), shallow=False)
    print("All four organisations produce identical output files (checked byte by byte): True")
    print("\n=== New report (absent 3 consecutive days): absent_3_days.txt ===")
    print(open(os.path.join(ref_a, "absent_3_days.txt")).read())

    print("=== Task 5.2 - effort of the change ===")
    print(f"{'organisation':<17} {'files':>5} {'lines':>6} | {'files changed':>13} {'lines added':>12}  changed files")
    for org in organisations(False):
        f1, l1 = count_lines(before, org)
        old, new = organisations(False)[org], organisations(True)[org]
        changed = [name for name in new if new[name] != old[name]]
        added = sum(1 for name in changed for ln in difflib.ndiff(old[name].splitlines(), new[name].splitlines()) if ln.startswith("+ "))
        print(f"{org:<17} {f1:>5} {l1:>6} | {len(changed):>13} {added:>12}  {', '.join(changed)}")

    print("\n=== Alternative concept: cost of importing the package ===")
    pkg = os.path.join(after, "d_package")
    code = (
        "import sys, time, tracemalloc\n"
        f"sys.path.insert(0, {pkg!r})\n"
        "before = set(sys.modules)\n"
        "tracemalloc.start()\n"
        "t0 = time.perf_counter()\n"
        "import attendance.reader, attendance.stats, attendance.report\n"
        "first = time.perf_counter() - t0\n"
        "mem = tracemalloc.get_traced_memory()[1]\n"
        "tracemalloc.stop()\n"
        "t0 = time.perf_counter()\n"
        "for _ in range(100000):\n"
        "    import attendance.stats\n"
        "again = (time.perf_counter() - t0) / 100000\n"
        "mine = sorted(m for m in sys.modules if m.startswith('attendance'))\n"
        "print(f'first import of the package: {first * 1000:.2f} ms, peak allocation {mem / 1024:.0f} KiB, '\n"
        "      f'{len(set(sys.modules) - before)} modules newly loaded ({mine})')\n"
        "print(f'repeat import statement (cached in sys.modules): {again * 1e9:.0f} ns each')\n"
    )
    print(subprocess.run([sys.executable, "-c", code], capture_output=True, text=True).stdout.strip())
    code1 = (
        "import sys, time\n"
        f"sys.path.insert(0, {os.path.join(after, 'a_one_script')!r})\n"
        "t0 = time.perf_counter()\n"
        "import attendance\n"
        "print(f'first import of the one-file script as a module: {(time.perf_counter() - t0) * 1000:.2f} ms')\n"
    )
    print(subprocess.run([sys.executable, "-c", code1], capture_output=True, text=True).stdout.strip())
