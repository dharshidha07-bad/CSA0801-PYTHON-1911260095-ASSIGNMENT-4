"""Task 5.3 - the three import styles, using the package attendance/ (organisation d)."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "organisations_after", "d_package"))

print("1) import attendance.stats")
import attendance.stats
print("   name bound in this program:", [n for n in ("attendance", "stats", "percentages") if n in globals()])
print("   call: attendance.stats.percentages(...) ->", attendance.stats.percentages({"192311001": [3, 1]}))

print("\n2) from attendance import stats")
from attendance import stats
print("   name bound:", [n for n in ("attendance", "stats", "percentages") if n in globals()])
print("   call: stats.percentages(...) ->", stats.percentages({"192311001": [3, 1]}))
print("   same module object as in style 1:", stats is attendance.stats)

print("\n3) from attendance.stats import percentages")
from attendance.stats import percentages
print("   name bound:", [n for n in ("attendance", "stats", "percentages") if n in globals()])
print("   call: percentages(...) ->", percentages({"192311001": [3, 1]}))
print("   same function object:", percentages is stats.percentages)

print("\nNaming conflict example: a local variable called 'percentages' hides style 3 but not styles 1 and 2")
percentages = [1, 2, 3]
print("   percentages ->", percentages, "| stats.percentages is still the function:", callable(stats.percentages))
print("   modules loaded once and cached:", all(m in sys.modules for m in ("attendance", "attendance.stats")))
