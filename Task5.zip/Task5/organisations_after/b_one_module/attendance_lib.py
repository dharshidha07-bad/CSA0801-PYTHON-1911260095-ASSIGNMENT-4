"""Library module: reading, statistics and reports."""
import csv
from datetime import datetime
from pathlib import Path


def check_line(line):
    """Return (reg, date, status) or raise ValueError(reason) for a damaged line."""
    text = line.strip()
    if not text:
        raise ValueError("empty line")
    parts = [p.strip() for p in text.split(",")]
    if len(parts) != 3:
        raise ValueError(f"expected 3 fields, found {len(parts)}")
    reg, date, status = parts
    if not (reg.isdigit() and len(reg) == 9):
        raise ValueError(f"invalid register number {reg!r}")
    try:
        datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        raise ValueError(f"invalid date {date!r}") from None
    if status not in ("P", "A"):
        raise ValueError(f"invalid status {status!r}")
    return reg, date, status


def read_month(folder):
    """One pass over the daily files. Returns (records, damaged)."""
    records, seen, damaged = [], set(), []
    for path in sorted(Path(folder).glob("attendance_*.txt")):
        try:
            with open(path, encoding="utf-8") as f:
                for line_no, line in enumerate(f, start=1):
                    try:
                        reg, date, status = check_line(line)
                        if (reg, date) in seen:
                            raise ValueError("duplicate record for this student and date")
                    except ValueError as err:
                        damaged.append((path.name, line_no, line.rstrip("\n"), str(err)))
                        continue
                    seen.add((reg, date))
                    records.append((reg, date, status))
        except (OSError, UnicodeDecodeError) as err:
            damaged.append((path.name, 0, "", f"file could not be read: {err}"))
    return records, damaged


def count_attendance(records):
    counts = {}
    for reg, date, status in records:
        entry = counts.setdefault(reg, [0, 0])
        entry[0 if status == "P" else 1] += 1
    return counts


def percentages(counts):
    return {reg: 100.0 * p / (p + a) for reg, (p, a) in counts.items()}


def below_threshold(pcts, limit=75.0):
    return sorted((reg, pct) for reg, pct in pcts.items() if pct < limit)


def absent_streaks(records, run_length=3):
    """Students absent on run_length or more consecutive recorded days: {reg: (first, last, days)}."""
    by_student = {}
    for reg, date, status in records:
        by_student.setdefault(reg, []).append((date, status))
    streaks = {}
    for reg, days in by_student.items():
        days.sort()
        run, best = [], []
        for date, status in days:
            if status == "A":
                run.append(date)
                if len(run) > len(best):
                    best = list(run)
            else:
                run = []
        if len(best) >= run_length:
            streaks[reg] = (best[0], best[-1], len(best))
    return streaks


def write_summary(path, counts, pcts):
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["register_number", "present", "absent", "percentage"])
        for reg in sorted(counts):
            w.writerow([reg, counts[reg][0], counts[reg][1], f"{pcts[reg]:.1f}"])


def write_below(path, below):
    with open(path, "w", encoding="utf-8") as f:
        for reg, pct in below:
            f.write(f"{reg} {pct:.1f}%\n")


def write_damaged(path, damaged):
    with open(path, "w", encoding="utf-8") as f:
        for name, no, text, reason in damaged:
            f.write(f"{name}:{no}: {reason} | {text!r}\n")


def write_streaks(path, streaks):
    with open(path, "w", encoding="utf-8") as f:
        for reg in sorted(streaks):
            first, last, n = streaks[reg]
            f.write(f"{reg} absent {n} days in a row: {first} to {last}\n")
