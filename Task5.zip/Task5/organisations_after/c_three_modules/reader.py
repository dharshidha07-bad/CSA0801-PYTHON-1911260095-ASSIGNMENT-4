"""Reading the daily files."""
from datetime import datetime
from pathlib import Path


def check_line(line):
    """Return (reg, date, status) or raise ValueError(reason) for a damaged line."""
    text = line.strip()
    if not text:
        raise ValueError("empty line")
    parts = [p.strip() for p in text.split(",")]
    if len(parts) != 3:
        raise ValueError(f"expected 3 fields, found {len(parts)}")
    reg, date, status = parts
    if not (reg.isdigit() and len(reg) == 9):
        raise ValueError(f"invalid register number {reg!r}")
    try:
        datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        raise ValueError(f"invalid date {date!r}") from None
    if status not in ("P", "A"):
        raise ValueError(f"invalid status {status!r}")
    return reg, date, status


def read_month(folder):
    """One pass over the daily files. Returns (records, damaged)."""
    records, seen, damaged = [], set(), []
    for path in sorted(Path(folder).glob("attendance_*.txt")):
        try:
            with open(path, encoding="utf-8") as f:
                for line_no, line in enumerate(f, start=1):
                    try:
                        reg, date, status = check_line(line)
                        if (reg, date) in seen:
                            raise ValueError("duplicate record for this student and date")
                    except ValueError as err:
                        damaged.append((path.name, line_no, line.rstrip("\n"), str(err)))
                        continue
                    seen.add((reg, date))
                    records.append((reg, date, status))
        except (OSError, UnicodeDecodeError) as err:
            damaged.append((path.name, 0, "", f"file could not be read: {err}"))
    return records, damaged
