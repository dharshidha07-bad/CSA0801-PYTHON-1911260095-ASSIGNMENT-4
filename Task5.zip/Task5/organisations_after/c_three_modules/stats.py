"""Statistics."""


def count_attendance(records):
    counts = {}
    for reg, date, status in records:
        entry = counts.setdefault(reg, [0, 0])
        entry[0 if status == "P" else 1] += 1
    return counts


def percentages(counts):
    return {reg: 100.0 * p / (p + a) for reg, (p, a) in counts.items()}


def below_threshold(pcts, limit=75.0):
    return sorted((reg, pct) for reg, pct in pcts.items() if pct < limit)


def absent_streaks(records, run_length=3):
    """Students absent on run_length or more consecutive recorded days: {reg: (first, last, days)}."""
    by_student = {}
    for reg, date, status in records:
        by_student.setdefault(reg, []).append((date, status))
    streaks = {}
    for reg, days in by_student.items():
        days.sort()
        run, best = [], []
        for date, status in days:
            if status == "A":
                run.append(date)
                if len(run) > len(best):
                    best = list(run)
            else:
                run = []
        if len(best) >= run_length:
            streaks[reg] = (best[0], best[-1], len(best))
    return streaks
