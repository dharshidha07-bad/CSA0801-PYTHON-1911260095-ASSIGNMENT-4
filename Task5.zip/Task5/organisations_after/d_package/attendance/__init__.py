"""attendance package: reader, stats and report sub-modules."""
__all__ = ["reader", "stats", "report"]
