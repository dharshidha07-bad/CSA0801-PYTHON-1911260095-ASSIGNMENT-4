"""Main script."""
import os
import sys

import attendance_lib as al


def run(data_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    records, damaged = al.read_month(data_dir)
    counts = al.count_attendance(records)
    pcts = al.percentages(counts)
    below = al.below_threshold(pcts)
    al.write_summary(os.path.join(out_dir, "attendance_summary.csv"), counts, pcts)
    al.write_below(os.path.join(out_dir, "below_75.txt"), below)
    al.write_damaged(os.path.join(out_dir, "damaged_lines.log"), damaged)
    print(f"{len(counts)} students, {len(below)} below 75%, {len(damaged)} damaged lines")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("usage: python main.py <data folder> <output folder>")
    run(sys.argv[1], sys.argv[2])
