"""Main script."""
import os
import sys

import reader
import stats
import report


def run(data_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    records, damaged = reader.read_month(data_dir)
    counts = stats.count_attendance(records)
    pcts = stats.percentages(counts)
    below = stats.below_threshold(pcts)
    report.write_summary(os.path.join(out_dir, "attendance_summary.csv"), counts, pcts)
    report.write_below(os.path.join(out_dir, "below_75.txt"), below)
    report.write_damaged(os.path.join(out_dir, "damaged_lines.log"), damaged)
    print(f"{len(counts)} students, {len(below)} below 75%, {len(damaged)} damaged lines")


if __name__ == "__main__":
    if len(sys.argv) != 3:
        sys.exit("usage: python main.py <data folder> <output folder>")
    run(sys.argv[1], sys.argv[2])
