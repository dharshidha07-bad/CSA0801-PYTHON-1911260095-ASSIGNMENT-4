"""Writing the reports."""
import csv


def write_summary(path, counts, pcts):
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["register_number", "present", "absent", "percentage"])
        for reg in sorted(counts):
            w.writerow([reg, counts[reg][0], counts[reg][1], f"{pcts[reg]:.1f}"])


def write_below(path, below):
    with open(path, "w", encoding="utf-8") as f:
        for reg, pct in below:
            f.write(f"{reg} {pct:.1f}%\n")


def write_damaged(path, damaged):
    with open(path, "w", encoding="utf-8") as f:
        for name, no, text, reason in damaged:
            f.write(f"{name}:{no}: {reason} | {text!r}\n")
