"""Statistics."""


def count_attendance(records):
    counts = {}
    for reg, date, status in records:
        entry = counts.setdefault(reg, [0, 0])
        entry[0 if status == "P" else 1] += 1
    return counts


def percentages(counts):
    return {reg: 100.0 * p / (p + a) for reg, (p, a) in counts.items()}


def below_threshold(pcts, limit=75.0):
    return sorted((reg, pct) for reg, pct in pcts.items() if pct < limit)
