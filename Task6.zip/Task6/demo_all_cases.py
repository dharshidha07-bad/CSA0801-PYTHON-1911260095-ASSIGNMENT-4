"""Task 6 Stage 5 - demonstration with clean files, then with every kind of problem; plus the
duplicate-detection comparison (set versus searching a list)."""
import os
import random
import time

from fest.pipeline import process
from fest.validators import parse_registration, valid_email
from fest.errors import RegistrationError

HERE = os.path.dirname(os.path.abspath(__file__))

print("=== Case 1: clean files (five departments, no problems) ===")
stats, accepted, errors, events = process(os.path.join(HERE, "input_clean"), os.path.join(HERE, "output_clean"))
print(f"accepted={stats['accepted']} errors={len(errors)} files_missing={stats['files_missing']}")
print(open(os.path.join(HERE, "output_clean", "summary.txt")).read())

print("=== Case 2: duplicate, invalid e-mails, damaged lines and a missing file together (see output/) ===")
stats, accepted, errors, events = process(os.path.join(HERE, "input"), os.path.join(HERE, "output"))
kinds = {}
for _, _, kind, _, _ in errors:
    kinds[kind] = kinds.get(kind, 0) + 1
print("accepted:", stats["accepted"], "| problems by kind:", kinds)
print("the program finished normally; the missing file and every bad line are in errors.log")

print("\n=== E-mail validation tests (string methods only) ===")
for email in ("a@b.com", "anitha.k@mail.co.in", "no_at.com", "a@@b.com", "@b.com", "a@", "a@b", "a@.com", "a@b.", "a b@c.com", "a@b..com"):
    print(f"  {email!r:<24} -> {valid_email(email)}")

print("\n=== Event-wise file written for 'Dance' ===")
print(open(os.path.join(HERE, "output", "events", "dance.txt")).read())

print("=== Other inputs: missing output folder is created; unreadable (wrong encoding) department file ===")
import shutil
import tempfile
tmp = tempfile.mkdtemp()
with open(os.path.join(tmp, "registrations_cse.txt"), "wb") as f:
    f.write(b"192311001,Anitha K,CSE,a@b.com,Quiz\n\xff\xfe,bad bytes\n")
stats, accepted, errors, _ = process(tmp, os.path.join(tmp, "new", "folder"))
print("accepted:", stats["accepted"], "| log:", [(e[0], e[2]) for e in errors if e[2] == "UNREADABLE_FILE"])
shutil.rmtree(tmp)

print("\n=== Alternative concept: duplicate detection with a set versus a list search ===")


def dup_set(regs):
    seen, dups = set(), 0
    for r in regs:
        if r in seen:
            dups += 1
        else:
            seen.add(r)
    return dups


def dup_list(regs):
    seen, dups = [], 0
    for r in regs:
        if r in seen:
            dups += 1
        else:
            seen.append(r)
    return dups


print(f"{'n':>7} {'set':>10} {'list search':>13} {'ratio':>8}")
for n in (1000, 5000, 10000, 20000):
    rnd = random.Random(1)
    regs = [f"1923{rnd.randrange(int(n * 0.9)):05d}" for _ in range(n)]
    assert dup_set(regs) == dup_list(regs)
    t0 = time.perf_counter(); dup_set(regs); a = time.perf_counter() - t0
    t0 = time.perf_counter(); dup_list(regs); b = time.perf_counter() - t0
    print(f"{n:>7} {a:>9.4f}s {b:>12.4f}s {b / a:>7.0f}x")
