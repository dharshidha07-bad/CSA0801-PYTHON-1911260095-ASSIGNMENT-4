"""fest package: processing of college-fest registrations.

readers      - open department files, yield raw lines (missing file / bad encoding are reported, not fatal)
validators   - parse one line into a Registration, validate fields and e-mail
writers      - master list, event files, summary, error log
pipeline     - connects the three parts and keeps the counters
errors       - the exceptions used by the package
"""
__all__ = ["readers", "validators", "writers", "pipeline", "errors"]
