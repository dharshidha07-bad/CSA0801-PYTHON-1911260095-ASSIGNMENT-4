"""Exceptions of the fest package."""


class RegistrationError(Exception):
    """Base class: a registration line that cannot be accepted."""


class DamagedLine(RegistrationError):
    """Wrong number of fields or an empty required field."""


class InvalidEmail(RegistrationError):
    """E-mail address fails the string checks."""


class DuplicateRegistration(RegistrationError):
    """The register number has already been accepted."""
