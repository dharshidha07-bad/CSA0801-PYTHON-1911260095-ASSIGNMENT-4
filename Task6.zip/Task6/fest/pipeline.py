"""The processing flow: read -> validate -> remove duplicates -> write."""
import os

from . import readers, validators, writers
from .errors import DamagedLine, DuplicateRegistration, InvalidEmail

DEPARTMENTS = ["cse", "it", "ece", "mech", "civil"]


def process(input_dir, output_dir, departments=DEPARTMENTS):
    """Never stops because of a bad line or a missing file; everything is recorded in the error log."""
    seen = set()                       # register numbers already accepted (O(1) duplicate test)
    accepted, errors, event_index = [], [], {}
    stats = {"files_expected": len(departments), "files_missing": 0, "missing_names": [], "lines": 0,
             "accepted": 0, "duplicates": 0, "invalid_email": 0, "damaged": 0, "by_department": {}}
    for dept in departments:
        name = f"registrations_{dept}.txt"
        path = os.path.join(input_dir, name)
        try:
            for line_no, text in readers.read_lines(path):
                stats["lines"] += 1
                try:
                    reg = validators.parse_registration(text)
                    if reg.reg_no in seen:
                        raise DuplicateRegistration(f"register number {reg.reg_no} already registered")
                except DuplicateRegistration as err:
                    stats["duplicates"] += 1
                    errors.append((name, line_no, "DUPLICATE", str(err), text))
                except InvalidEmail as err:
                    stats["invalid_email"] += 1
                    errors.append((name, line_no, "INVALID_EMAIL", str(err), text))
                except DamagedLine as err:
                    stats["damaged"] += 1
                    errors.append((name, line_no, "DAMAGED", str(err), text))
                else:
                    seen.add(reg.reg_no)
                    accepted.append(reg)
                    stats["accepted"] += 1
                    stats["by_department"][reg.department] = stats["by_department"].get(reg.department, 0) + 1
                    for event in reg.events:
                        event_index.setdefault(event, set()).add((reg.reg_no, reg.name))
        except FileNotFoundError:
            stats["files_missing"] += 1
            stats["missing_names"].append(name)
            errors.append((name, 0, "MISSING_FILE", "department file not found", ""))
        except (PermissionError, UnicodeDecodeError) as err:
            errors.append((name, 0, "UNREADABLE_FILE", f"{type(err).__name__}: {err}", ""))
    os.makedirs(output_dir, exist_ok=True)
    writers.write_master(os.path.join(output_dir, "master_list.csv"), accepted)
    writers.write_event_files(os.path.join(output_dir, "events"), event_index)
    writers.write_errors(os.path.join(output_dir, "errors.log"), errors)
    writers.write_summary(os.path.join(output_dir, "summary.txt"), stats, event_index)
    return stats, accepted, errors, event_index
