"""Reading one department file."""


def read_lines(path):
    """Yield (line_number, text) for every non-empty line of the file.

    FileNotFoundError / PermissionError / UnicodeDecodeError are NOT caught here: the pipeline decides
    what to do, so the reader stays simple and the decision is made in one place.
    """
    with open(path, encoding="utf-8") as f:
        for line_no, line in enumerate(f, start=1):
            if line.strip():
                yield line_no, line.rstrip("\n")
