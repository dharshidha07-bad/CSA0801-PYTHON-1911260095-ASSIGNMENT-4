"""Parsing and validation of one registration line using string methods only."""
from collections import namedtuple

from .errors import DamagedLine, InvalidEmail

Registration = namedtuple("Registration", "reg_no name department email events")


def valid_email(email):
    """exactly one '@', non-empty local part, domain with an inner '.', no spaces, no '..'."""
    if " " in email or email.count("@") != 1:
        return False
    local, domain = email.split("@")
    if not local or not domain:
        return False
    if ".." in email or domain.startswith(".") or domain.endswith(".") or "." not in domain:
        return False
    return True


def parse_registration(line):
    """'192311001,Anitha,CSE,anitha@mail.com,Dance;Quiz' -> Registration. Raises DamagedLine / InvalidEmail."""
    parts = [p.strip() for p in line.strip().split(",")]
    if len(parts) != 5:
        raise DamagedLine(f"expected 5 fields, found {len(parts)}")
    reg_no, name, department, email, events_text = parts
    if not (reg_no.isdigit() and len(reg_no) == 9):
        raise DamagedLine(f"invalid register number {reg_no!r}")
    if not name or not department:
        raise DamagedLine("name or department is empty")
    events = [e.strip().title() for e in events_text.split(";") if e.strip()]
    if not events:
        raise DamagedLine("no event chosen")
    if not valid_email(email):
        raise InvalidEmail(f"invalid e-mail {email!r}")
    return Registration(reg_no, name, department.upper(), email.lower(), events)
