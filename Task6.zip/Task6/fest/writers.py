"""Writing the output files."""
import csv
import os
import re


def write_master(path, registrations):
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        w.writerow(["register_number", "name", "department", "email", "events"])
        for r in sorted(registrations, key=lambda r: r.reg_no):
            w.writerow([r.reg_no, r.name, r.department, r.email, ";".join(r.events)])


def write_event_files(folder, event_index):
    os.makedirs(folder, exist_ok=True)
    for event, members in event_index.items():
        file_name = re.sub(r"[^a-z0-9]+", "_", event.lower()).strip("_") + ".txt"
        with open(os.path.join(folder, file_name), "w", encoding="utf-8") as f:
            for reg_no, name in sorted(members):
                f.write(f"{reg_no} {name}\n")


def write_errors(path, errors):
    with open(path, "w", encoding="utf-8") as f:
        for source, line_no, kind, message, text in errors:
            f.write(f"{source}:{line_no}: {kind}: {message} | {text!r}\n")


def write_summary(path, stats, event_index):
    with open(path, "w", encoding="utf-8") as f:
        f.write("FEST REGISTRATION SUMMARY\n")
        f.write(f"Files expected      : {stats['files_expected']}\n")
        f.write(f"Files missing       : {stats['files_missing']} {stats['missing_names']}\n")
        f.write(f"Lines read          : {stats['lines']}\n")
        f.write(f"Accepted (master)   : {stats['accepted']}\n")
        f.write(f"Duplicates          : {stats['duplicates']}\n")
        f.write(f"Invalid e-mails     : {stats['invalid_email']}\n")
        f.write(f"Damaged lines       : {stats['damaged']}\n")
        f.write("Participants by department:\n")
        for dept in sorted(stats["by_department"]):
            f.write(f"  {dept:<6} {stats['by_department'][dept]}\n")
        f.write("Participants by event:\n")
        for event in sorted(event_index):
            f.write(f"  {event:<14} {len(event_index[event])}\n")
