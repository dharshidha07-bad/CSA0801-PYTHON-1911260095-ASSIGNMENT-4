"""Run the fest registration package:  python main.py [input folder] [output folder]"""
import os
import sys

from fest.pipeline import process

HERE = os.path.dirname(os.path.abspath(__file__))

if __name__ == "__main__":
    in_dir = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "input")
    out_dir = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "output")
    stats, accepted, errors, events = process(in_dir, out_dir)
    print(f"accepted {stats['accepted']} registrations, logged {len(errors)} problems; outputs in {out_dir}")
